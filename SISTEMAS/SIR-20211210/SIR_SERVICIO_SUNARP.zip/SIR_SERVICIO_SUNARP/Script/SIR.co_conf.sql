DECLARE
  vn_existe NUMBER := 0;
BEGIN

  INSERT INTO orlcdba.co_conf (co_conf, vl_conf) VALUES ('TSA_FLAG', 'S');

  SELECT COUNT(1) INTO vn_existe FROM orlcdba.co_conf WHERE co_conf = 'TSA_SUNARP_USER';
  IF vn_existe = 0 THEN
    INSERT INTO orlcdba.co_conf (co_conf, vl_conf) VALUES ('TSA_SUNARP_USER', 'tssuser');
  ELSE
    UPDATE orlcdba.co_conf SET vl_conf = 'tssuser' WHERE co_conf = 'TSA_SUNARP_USER';
  END IF;

  SELECT COUNT(1) INTO vn_existe FROM orlcdba.co_conf WHERE co_conf = 'TSA_SUNARP_PASS';
  IF vn_existe = 0 THEN
    INSERT INTO orlcdba.co_conf (co_conf, vl_conf) VALUES ('TSA_SUNARP_PASS', '76ba1bf3741e');
  ELSE
    UPDATE orlcdba.co_conf SET vl_conf = '76ba1bf3741e' WHERE co_conf = 'TSA_SUNARP_PASS';
  END IF;

  SELECT COUNT(1) INTO vn_existe FROM orlcdba.co_conf WHERE co_conf = 'TSA_SUNARP_URL';
  IF vn_existe = 0 THEN
    INSERT INTO orlcdba.co_conf (co_conf, vl_conf) VALUES ('TSA_SUNARP_URL', 'http://tsa.sunarp.gob.pe/tsa/sunarp');
  ELSE
    UPDATE orlcdba.co_conf SET vl_conf = 'http://tsa.sunarp.gob.pe/tsa/sunarp' WHERE co_conf = 'TSA_SUNARP_URL';
  END IF;

END;
/